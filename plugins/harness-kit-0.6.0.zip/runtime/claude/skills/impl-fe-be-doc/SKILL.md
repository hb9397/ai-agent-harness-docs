---
name: impl-fe-be-doc
description: >
  설계가 끝난 뒤 FE↔API↔BE↔DB를 함께 연결하거나 여러 화면·기능을 조율하는
  구현 순서와 작업 단위를 정리할 때 사용한다.
  'FE BE 통합 작업지침서', '풀스택 구현 계획', 'FE/BE Phase 나눠줘',
  '태스크 쪼개줘', '어떤 순서로 개발하면 돼?', '화면별 구현 지침',
  '화면 단위 명세', 'SFR 화면 구현', '화면별 컴포넌트 설계' 요청이 오면 이 스킬을 쓴다.
  설계 문서 → FE/BE 페어 또는 다중 화면 중심 Phase별 작업지침서 자동 생성.
  단일 BE 엔드포인트나 단일 FE 컴포넌트처럼 독립된 소규모 작업은 impl-doc을 쓴다.
allowed-tools: Read, Glob, Grep, Write, Agent
---

## 문서 루트 계약

이 스킬이 하네스 문서를 읽거나 쓸 때 사용하는 정본은 `.ai-docs/`뿐이다. 작업 전에
`.ai-docs/`와 이전 `.docs/`의 존재를 확인한다. `.docs/`만 있거나 두 경로가 함께
있으면 하네스 문서를 읽거나 쓰지 않고 `harness-setup`의 명시적 문서 루트 이관·충돌
해결을 먼저 요청한다. 이전 경로를 호환 별칭으로 추측하지 않는다. 애플리케이션 소스
작업 자체의 권한과 가능 여부는 이 문서 루트 판정으로 제한하지 않는다.


# FE/BE 및 화면 중심 작업지침서 생성 (impl-fe-be-doc)

design-doc 스킬의 OUTPUT 또는 별도 설계 문서를 입력받아
AI Agent 및 개발자가 참조하는 FE/BE 페어 기능 단위 또는 화면 중심 구현 명세서를 생성한다.

생성 전 반드시 사용자 확인을 거친다. 파일을 무단으로 수정하지 않는다.

계획서·roadmap index 저장 경로·소유권·인계는 단일 앱의
`@.ai-docs/instruction/artifact-output-routing-instruction.md` 또는 복수 앱의
`@.ai-docs/{앱}/instruction/artifact-output-routing-instruction.md`를 따른다.

> 이 문서는 AI Agent가 코드를 작성하는 순서와 기준이 된다.
> Phase 경계, 태스크 의존 관계, 검증 시나리오가 불명확하면
> Agent가 잘못된 순서로 구현하거나 검증 없이 다음 단계로 넘어가는 문제가 생긴다.
> 각 Phase는 독립 실행·테스트 가능해야 하고, 웹앱에서는 BE/FE 페어가 함께 완성되어야 한다.
> 화면 중심 작업에서는 화면 1개를 Phase 단위로 삼되, 그 화면에 필요한 BE API·FE 컴포넌트·상태·검증을 한 번에 명세한다.

## 스킬 연계

이 스킬은 단독으로도 사용할 수 있지만, 아래 순서로 연계했을 때 가장 효과적이다.

```
design-doc (설계 인터뷰 → OUTPUT 문서)
    ↓ OUTPUT 문서를 그대로 이 스킬에 입력
impl-fe-be-doc → FE/BE 페어 또는 화면 중심 작업지침서
    └─→ 같은 디렉토리의 로드맵 인덱스 문서
        {YYMMDD}-0.{앱이름}-roadmap-impl-index.md 생성/갱신 (Step 0-C, Step 8)
            ├─→ impl-reuse-scan → Phase/태스크 시작 preflight (필수 또는 not-applicable)
            ├─→ 실제 구현
            ├─→ impl-verify → Phase/태스크 종료 명시적 게이트
            ├─→ multi-review
            └─→ doc-audit
```

design-doc OUTPUT의 각 섹션은 아래와 같이 매핑된다.

| design-doc OUTPUT 섹션 | 사용 위치 |
|------------------------|----------|
| 01 개요, 02 동작 흐름 | Phase 분할 기준 / 검증 시나리오 |
| 03 집중 로직 | 핵심 Phase 태스크 (가장 상세하게) |
| 04 인터페이스 설계 | FE-XX 태스크 Agent 지시 |
| 05 데이터 설계 | BE-XX DB 모델 태스크 |
| 06 파일 구성 | [NEW] / [MODIFY] 구분 기준 |
| 화면 목록 / 화면정의서 / RFP·SFR 원문에서 직접 추출한 화면 후보 | 화면 중심 Phase, 컴포넌트/API/상태 명세 |
| 10 주의사항 | 전역 주의사항 섹션 |
| 12 열린 결정 사항 | 미결 사항 섹션 |

---

## 워크플로우

### Step 0 — 플랫폼·실행 방식 확인 + 프로젝트 유형 확인

#### Step 0-A — 플랫폼·실행 방식 확인

현재 호스트가 독립 작업을 병렬 실행할 수 있는지는 노출된 도구로 확인한다.
관찰 가능한 플랫폼 이름을 사용자에게 다시 묻지 않는다. 작업이 서로 독립적이고
병렬 실행이 실질적으로 유리할 때만 선호를 확인하며, 미지원 또는 미사용 시 순차 실행한다.

#### Step 0-B — 프로젝트 유형 확인 (C-1 확인 단계)

작업지침서 생성 범위를 확정하기 위해 **반드시** 아래를 수행한다.

1. 현재 수행 위치에서 프로젝트 구조를 탐색한다 (git repo 경계, 하위 앱 폴더 후보 스캔).
2. **단일 애플리케이션 프로젝트**인지 **복수 애플리케이션 프로젝트**인지 판정한다.
3. 판정 결과 + 적용 대상 애플리케이션(폴더)을 사용자에게 **반드시 재확인**한다.
4. 확인된 범위 밖은 건드리지 않는다.

> ✋ **확인 게이트**
>
> - 프로젝트 유형: **단일 / 복수** 애플리케이션
> - 적용 대상 애플리케이션(폴더): `{폴더명}`
>
> 맞습니까? **(승인 / 수정 / 취소)**

---

### Step 0-C — design-roadmap·roadmap index preflight

계획서를 쓰기 전에 설계 로드맵의 기준 위치와 기존 인덱스를 먼저 식별한다.
이 단계는 문서를 생성하지 않으며, reuse/verify를 실행하지 않는다.

1. 현재 프로젝트 루트와 대상 앱을 확정한 뒤 `design-roadmap` 디렉토리를 탐색한다.
2. 사용자 식별자 `{사용자}`를 정하고 `../impl-doc/{사용자}/` 후보와 앱별
   `.ai-docs/{앱}/impl-doc/{사용자}/`를 모두 스캔한다.
3. 기존 `*-roadmap-impl-index.md`를 검색한다. 정확히 하나면 기준으로 채택하고,
   없으면 계획서 저장 전에 `{YYMMDD}-0.{앱이름}-roadmap-impl-index.md`를
   먼저 만든다. 둘 이상이거나 경로가 모호하면 저장을 중단하고 사용자에게
   선택을 요청한다.
4. 인덱스에는 대상 앱, 사용자, 설계 로드맵 경로, 현재 Phase/태스크 경계를
   기록하고 이후 Step 8에서 계획서 링크와 상태를 갱신한다.

---

### Step 1 — 입력 문서 수집 및 사전 질문

설계 문서가 제공되지 않은 경우 요청한다.

> "작업지침서를 만들 설계 문서나 요구사항 원문을 공유해 주세요.
> design-doc 스킬의 결과물, 기존 PRD/설계서, 화면정의서, RFP/SFR 원문 모두 가능합니다."

RFP/SFR 원문이 제공되면 별도 사전 스킬을 요구하지 않고 이 스킬 안에서 구현 계획에 필요한 최소 범위만 직접 해석한다.

- 요구사항 ID, 원문 범위, 필수 기능, 인터페이스 후보, 데이터 후보, 화면 후보를 추출한다.
- 확정되지 않은 화면·API·데이터는 후보로 표시하고 Step 1의 우선순위 질문에 포함한다.
- 삭제된 별도 RFP 처리 스킬의 전체 로직을 복제하지 않는다.

문서를 받으면 `prompts/analysis.md` 기준으로 분석한다.
분석 후 불명확한 항목 중 우선순위 높은 것 **최대 3개만** 골라 한 번에 묻는다.
구체적인 확인 우선순위는 `prompts/analysis.md` 참조.

---

### Step 2 — Phase 분할

`prompts/phase-design.md` 의 분할 기준으로 Phase를 설계한다.
화면 중심으로 판단되면 `prompts/screen-analysis.md`의 화면 식별·의존 관계 분석을 함께 사용한다.

Phase 분할 원칙:
- 각 Phase는 이전 Phase 없이 실행 불가능해야 한다
- 각 Phase 끝에서 사람이 눈으로 확인할 수 있는 결과물이 있어야 한다
- BE만 또는 FE만 완성되는 Phase는 페어가 아니다 — 합치거나 재분할한다
- 한 Phase에 API 5개 이상이면 쪼갠다
- 스케일이 프로젝트 전체가 아니면 Phase 0(인프라)을 생략한다
- 화면 중심 Phase는 "화면 1개 = Phase 1개"를 기본으로 하되, 공통 레이아웃·인증·공통 API가 먼저 필요하면 선행 Phase로 분리한다

Phase 설계 초안을 내부적으로 확정한 뒤 Step 3으로 진행한다.

---

### Step 3 — 태스크 작성

`prompts/task-rules.md` 의 태스크 작성 규칙에 따라 각 Phase의 태스크를 작성한다.
산출물의 전체 섹션·필드 순서는 bundled 보호 자산인
`templates/impl-workflow.md.template`을 정식 output contract로 사용한다. 실제
산출물에서는 placeholder와 주석을 정리하되 템플릿 파일 자체를 삭제·이동·대체하지
않는다.
화면 중심 Phase에서는 `prompts/component-design.md`와 `prompts/api-mapping.md`를 함께 참조하여 화면별 컴포넌트 구조·API 연동·상태 관리·인터랙션 시나리오를 포함한다.

태스크 ID 체계:
- `INF-XX` : 인프라
- `BE-XX` : 백엔드
- `FE-XX` : 프론트엔드
- 번호는 Phase 내 순서가 아닌 전체 문서 통합 일련번호

각 태스크 필수 항목:
- 태스크 ID + 이름 + 파일 경로
- 의존 태스크
- 구현 내용 (무엇을 왜)
- Agent 지시 (핵심 시그니처 / 주의 분기 — 선택)
- 검증 기준

화면 중심 Phase 필수 항목:
- 화면 개요 (목적, 사용자, 진입/이탈 경로, 대응 SFR/REQ)
- 컴포넌트 트리와 주요 컴포넌트 책임
- 화면별 API 연동 표 (호출 시점, 요청/응답, 에러 처리)
- 상태 관리 표 (로컬/서버/전역 상태 구분)
- Happy Path, 에러 흐름, 에지 케이스

---

### Step 4 — 검증 시나리오 작성

각 Phase의 통합 검증을 `prompts/verification.md` 형식으로 작성한다.
화면 중심 Phase는 화면별 검증 체크리스트 형식을 함께 사용한다.

검증 시나리오는 사람이 직접 수행하는 것처럼 단계별로 서술한다.
합격 조건은 구체적인 확인 대상을 명시한다. ("정상 동작 확인" 금지)

---

### Step 5 — 함정 체크

`prompts/pitfall-checklist.md` 의 체크리스트를 실행하여 누락 항목을 검토한다.
문제 발견 시 해당 태스크에 반영하거나 주의사항으로 추가한다.

---

### Step 6 — 초안 출력 및 사용자 확인

작업지침서 초안을 대화창에 출력하고 승인을 요청한다.

> "위 작업지침서를 검토해 주세요.
> Phase 구성이나 태스크 내용 중 수정할 부분이 있으면 말씀해 주세요."

수정 요청 시 해당 Phase / 태스크만 재작성한다.

---

### Step 7 — 기능 이름 · 구현 종류 · 저장 위치 결정 · 파일 저장

승인 후에만 진행한다. 파일을 무단으로 생성·수정하지 않는다.

**① 기능 이름(slug) 질문** — 파일명에 들어갈 이번 기능 이름을 사용자에게 묻는다.

> "이번에 작성하는 작업지침서의 기능 이름을 알려주세요. (예: checkout-flow, admin-dashboard)"

받은 이름은 kebab-case로 정규화하여 `{slug}`로 쓴다.

**② 구현 종류(kind) 질문** — 이 문서가 다루는 작업 성격을 한 단어로 묻는다.

> "이 작업지침서가 다루는 구현 종류를 한 단어로 알려주세요.
> (예: pair, screen, api, ui, e2e, refactor — FE/BE 페어이면 `pair`, 화면 중심이면 `screen` 등 자유롭게 한 단어)"

받은 값은 소문자 kebab-case 한 단어로 정규화하여 `{kind}`로 쓴다.

**③ 사용자(`{사용자}`) 확인** — 다음 순서로 정한다.

1. `git config user.name`으로 현재 git 계정을 탐색한다.
2. 탐색되면 사용자에게 **반드시** 확인받는다.
   > "현재 git 계정은 `{git_user}`입니다. 이 이름으로 저장할까요? 다른 이름을 원하면 알려주세요."
3. git 계정이 없거나 사용자가 다른 이름을 원하면 직접 입력받는다.

**④ 저장 디렉토리 결정** — 프로젝트 유형에 따라 분기한다.

- **단일 앱**: `.ai-docs/impl-doc/{사용자}/`
- **복수 앱**: `.ai-docs/{앱}/impl-doc/{사용자}/` (예: `.ai-docs/app-frontend/impl-doc/developer/`)

디렉토리가 없으면 생성한다.

**⑤ 파일명 산정 (날짜 + 순번)**

파일명 포맷:
```
{YYMMDD}-{seq}.{slug}-impl-{kind}.md
```

- `{YYMMDD}` — 작성/갱신 시점 오늘 날짜를 2자리 연/월/일로 (예: 2026-06-30 → `260630`).
- `{seq}` — **저장 디렉토리 안에서 `{YYMMDD}-` 접두 파일들의 최대 순번 + 1** (없으면 `1`). 디렉토리를 `ls`로 스캔하여 같은 날짜의 가장 큰 `-N` 을 찾아 산정한다.
- `{slug}` — ①에서 받은 기능명(kebab-case).
- `{kind}` — ②에서 받은 구현 종류 한 단어.

예시:
- `.ai-docs/app-frontend/impl-doc/developer/260630-1.checkout-flow-impl-pair.md`
- `.ai-docs/app-frontend/impl-doc/developer/260630-2.admin-dashboard-impl-screen.md`
- `.ai-docs/app-frontend/impl-doc/developer/260630-3.checkout-flow-impl-e2e.md`

> 📌 이 네이밍 규칙은 `impl-doc` 스킬과 **완전히 동일**하다. 두 스킬 산출물은 같은 디렉토리에 섞여도 시간순으로 정렬되며, 작성 스킬 구분은 문서 머리말의 `생성 스킬:` 표기로만 한다.

**⑥ 중복 검사 및 갱신 처리**

새로 쓰기 전에 같은 저장 디렉토리에서 **`{slug}-impl-{kind}.md` 로 끝나는 기존 파일**을 모두 찾는다.

| 상황 | 처리 |
|------|------|
| 동일 `{slug}-impl-{kind}` 파일 없음 | 신규 생성 (⑤ 파일명 그대로) |
| 동일 `{slug}-impl-{kind}` 파일 1개 이상 존재 | 사용자에게 "**기존 파일을 갱신할지 / 새 버전으로 신규 생성할지**"를 묻는다 |
| 비슷하지만 slug/kind가 다른 후보 | 화면에 나열하고 "동일 작업인지" 확인 |

**갱신을 선택한 경우**:
- 갱신 대상 기존 파일을 **⑤에서 산정한 새 파일명(현재 날짜·순번)으로 rename** 한다.
- 내용은 새로 작성한 본문으로 덮어쓴다.
- 문서 머리말에 **갱신일자**를 갱신/추가한다.
- 다른 사용자/git 계정이 작성한 파일을 갱신하는 경우, 머리말에 **갱신자(사용자 이름 또는 git 계정)를 추가 표기**한다.

**신규 생성을 선택한 경우**:
- ⑤ 파일명 그대로 새 파일을 만든다 (기존 파일은 손대지 않는다).

**⑦ 공통 규칙**

- 파일명은 스킬별로 구분하지 않는다. **어떤 스킬로 만들었는지는 문서 머리말의 `생성 스킬: impl-fe-be-doc` 표기로만 구분**한다.
- 저장 직전에 `{slug}`, `{kind}`, 최종 파일명을 사용자에게 한 번 더 확인한다.
  > "다음 파일명으로 저장합니다: `{YYMMDD}-{seq}.{slug}-impl-{kind}.md`. 맞나요?"

---

### Step 8 — 로드맵 인덱스 문서 생성·갱신

Step 7 저장이 끝난 뒤 **반드시** 수행한다. 대상은 Step 7 ④에서 정한 저장 디렉토리
(`.ai-docs/impl-doc/{사용자}/` 또는 `.ai-docs/{앱}/impl-doc/{사용자}/`) 안의
**로드맵 인덱스 문서 1개**다. 이 문서는 impl-doc/impl-fe-be-doc이 함께 쓰는 공용 산출물이며,
"이 디렉토리에 어떤 impl 문서들이 있고, 지금 어디까지 왔는가"를 한 곳에서 보여준다.
`impl-doc`으로 만든 산출물과 같은 디렉토리에 섞여도 인덱스는 하나만 유지한다.

**① 인덱스 파일 탐색** — 저장 디렉토리를 스캔해 `*-roadmap-impl-index.md`로 끝나는 파일을 찾는다.

**② 최초 사용 (인덱스 파일 없음)** — 이 스킬로 해당 디렉토리에 생성하는 **첫 문서**라면,
Step 7에서 방금 저장한 문서와 같은 자리에 인덱스 문서를 새로 만든다.

파일명 포맷 (일반 impl 문서와 순번 체계를 분리하기 위해 `{seq}`를 항상 `0`으로 고정):
```
{YYMMDD}-0.{앱이름}-roadmap-impl-index.md
```
- `{YYMMDD}` — 인덱스 문서를 처음 만드는 시점의 날짜. 이후 문서 내용이 갱신되어도 파일명은 **바꾸지 않는다** (일반 impl 문서처럼 최신 날짜로 rename하지 않음).
- `{앱이름}` — 단일앱은 프로젝트명, 복수앱은 대상 애플리케이션 폴더명(예: `collector`, `portal`).

구조는 현재 프로젝트의 기존 `*-roadmap-impl-index.md`가 있으면 그 사용자 확장을
보존해 따르고, 없으면 아래의 일반 섹션 계약으로 새로 만든다:
- 머리말: 생성 스킬, 작성일자, 갱신일자, 작성/갱신 계정, 목적, 현재 진행 위치
- `impl-doc 분할 구조` 표: 문서 목록(순서/문서명/상태/범위)
- 전체 페이즈·단계 경계(있다면) 또는 화면/기능 로드맵 개요
- 단계별 상세(진행 중/예정 단계는 방향만, 착수 시 구체화한다고 명시)
- 미래 단계 공통 원칙

**③ 이미 사용 중 (인덱스 파일 있음)** — Step 7에서 신규 문서를 만들었거나 기존 문서를 갱신했다면,
그 변화를 인덱스 문서에 **바로 반영**한다:
- 신규 문서 추가 시: 분할 구조 표에 새 행 추가, 상태를 진행 상황에 맞게 표기
- 기존 문서 갱신 시: 해당 행의 상태·범위 설명을 갱신
- 머리말의 `갱신일자`와 `현재 진행 위치`를 항상 최신 상태로 갱신
- 갱신자가 원작성자와 다르면 머리말에 갱신 계정을 추가 표기 (Step 7 ⑥과 동일 규칙)

**④ 인덱스 파일이 없는데 impl 문서가 이미 존재하는 경우** — 이번이 이 스킬로 만드는 첫 문서가 아니더라도
인덱스 파일 자체가 없으면 ②의 규칙으로 새로 만들되, 디렉토리를 스캔해 기존 impl 문서들(다른 스킬로 만든 문서 포함)을 분할 구조 표에 **소급 반영**한다.

**⑤ 저장 전 확인** — 인덱스 문서의 신규 생성/갱신 내용을 요약해 사용자에게 보여주고 저장한다. 별도 승인 게이트 없이 Step 7 승인에 포함된 것으로 간주하되, 인덱스 문서만 크게 구조가 바뀌는 경우(최초 생성, 스테이지/화면 경계 변경 등)에는 저장 직전 한 번 더 확인한다.

---

## 문서 개선 후처리와 완료 게이트

직접 호출에서는 FE/BE 구현 계획서와 로드맵 인덱스를 하나의 bundle로 묶는다.
상위 producer가 전달한 실행 컨텍스트가 있으면 새 ID나 owner를 만들지 않는다.

```text
artifact_bundle_id = impl-fe-be-doc:{정규화한 프로젝트 루트}:{이번 실행의 고유 ID}
handoff_owner = impl-fe-be-doc
suppress_child_handoff = false
handoff_completed = false
```

Step 7의 계획서 저장 검증과 Step 8의 인덱스 링크·분할 구조 검증을 모두 마친 뒤,
owner이고 억제되지 않았으며 아직 완료되지 않은 bundle에 대해서만
`humanize-korean`의 `document-refinement` 프로필을 한 번 제안한다. 상위
producer가 owner이면 초안과 검증 결과만 반환한다.

최종 검증된 계획서·인덱스의 정규화 상대경로와 각 파일 SHA-256, profile 이름을
정렬해 `artifact_bundle_fingerprint`를 계산한다. `.ai-docs/.harness/
humanize-handoffs.json` 원자적 ledger에서 같은 fingerprint의 완료 상태
(`proposed`, `skipped`, `rejected`, `applied`, `revalidated`)를 찾으면 새
session에서도 재제안하지 않는다. 새 결정은 bundle ID, owner, 파일 hash, 시각과
함께 기록하고 승인 반영 후에는 `applied`와 `revalidated`를 순서대로 갱신한다.
ledger 자체는 개선 대상에서 제외하며 기록할 수 없으면 현재 session 한정이라고
보고한다.

기본은 proposal-only이며 사용자 승인 전 파일 반영은 금지한다. 화면 ID, API ID,
파일 경로, 명령어, 표 구조, 숫자, 날짜, 의무 수준 표현은 보존한다.
제안·건너뛰기·거절 중 하나가 결정되면 `handoff_completed = true`와 ledger 상태를
함께 기록한다.

승인된 변경을 반영한 경우 FE↔API↔BE↔DB 추적, 태스크 ID, 파일 경로, 검증
시나리오와 Step 8 인덱스 링크를 다시 검증한다. 재검증된 계획서와 인덱스만
downstream 구현·검증 스킬의 입력으로 사용한다.

## downstream 구현·검증 handoff

계획서가 완료되면 다음 계약을 문서 머리말 또는 인덱스에 남긴다.

```yaml
downstream:
  roadmap_index: "{정규화 상대경로}"
  phase: "{phase-id}"
  reuse_scan:
    skill: "impl-reuse-scan"
    trigger: "phase-or-task-start"
    status: "required-or-not-applicable"
    input: "approved-plan-and-roadmap-index"
    decision: "reuse|extend|new"
    evidence: "{scan-result-or-not-applicable-reason}"
  verify:
    skill: "impl-verify"
    trigger: "phase-or-task-end"
    invocation: "explicit-only"
    status: "pass|fail|not-run"
    input: "implementation-diff-and-acceptance-criteria"
    evidence: "{verification-report-or-not-run-reason}"
```

각 Phase/태스크 시작 시 `$impl-reuse-scan`을 호출해 기존 구현·산출물을
확인하고, 종료 시 `$impl-verify`를 명시적으로 호출한다. 두 호출은 자동
모델 invocation이 아니며, reuse scan은 not-applicable 사유를 남길 수 있다.
`impl-verify`가 FAIL이면 다음 Phase 추천이나 완료 보고를 진행하지 않는다.
