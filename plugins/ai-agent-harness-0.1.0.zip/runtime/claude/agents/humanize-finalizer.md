---
name: humanize-finalizer
description: "Runtime support agent allowed for the ai-agent-harness humanize-korean Claude projection."
---

# humanize-finalizer

This generated runtime agent is allowed by `maintainer/plugin/runtime-allowlist.json`.

It must only support the `humanize-korean` document-refinement flow and must not introduce model pinning, external plugin-cache paths, or additional upstream agents.
